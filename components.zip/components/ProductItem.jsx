"use client";

const ProductItem = ({ products = [] }) => {
  return (
    <>
      {products.map((item) => (
        <div
          key={item.id}
          style={{
            border: "2px solid red",
            padding: "20px",
            margin: "10px",
            background: "white",
          }}
        >
          <img
            src={item.image}
            alt={item.name}
            width={150}
            height={150}
          />

          <h2>{item.name}</h2>
          <p>{item.brand}</p>
          <p>₹{item.price}</p>
        </div>
      ))}
    </>
  );
};

export default ProductItem;